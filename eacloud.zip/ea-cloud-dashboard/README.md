# EA Cloud Dashboard

Sistem remote-control untuk EA MT4/MT5 — cara kerjanya seperti cPanel/TeamViewer,
tapi yang dikontrol adalah Expert Advisor yang berjalan di terminal/VPS Anda.

Website **tidak** melakukan trading langsung. Website hanya menyimpan setting &
antrian perintah; EA di MT4/MT5-lah yang membaca dan mengeksekusinya.

```
   USER (browser)
        │
   Dashboard (HTML/CSS/JS) ── polling tiap 3s
        │
   REST API (Node/Express)
        │
   ┌────┴─────┐
   │          │
 Redis      MySQL
(realtime)  (persisten: users, license,
             settings, commands, history)
        │
   EA MT4 / EA MT5  (VPS/terminal user)
        │
   Broker Server ──► Market
```

## Kenapa dipisah Redis vs MySQL

| Data | Frekuensi tulis | Disimpan di |
|---|---|---|
| Balance, equity, margin, floating, ping, status online | tiap 2–5 detik per akun | **Redis**, key expire otomatis (TTL) → kalau EA berhenti kirim, status otomatis jadi "offline" |
| Settings EA (lot, TP, grid, magic, dst) | hanya saat user mengubah dari dashboard | MySQL, di-cache 10s di Redis supaya polling EA tidak membebani DB |
| Perintah (start/stop/close all/dst) | hanya saat user klik tombol | MySQL (frekuensi rendah, aman) |
| History transaksi, log | batch/periodik | MySQL |

Kalau semua data realtime ditulis ke MySQL tiap beberapa detik x ratusan akun,
itu yang bikin shared hosting kena I/O tinggi lalu diblokir/disuspend. Dengan
arsitektur ini, MySQL hanya tersentuh saat ada aksi user — bukan tiap heartbeat EA.

## Struktur folder

```
ea-cloud-dashboard/
├── database/schema.sql        # Skema MySQL (data persisten saja)
├── backend/                   # REST API (Node.js + Express)
│   ├── config/db.js           # Koneksi MySQL (pool)
│   ├── config/redis.js        # Koneksi Redis (data realtime)
│   ├── middleware/auth.js     # JWT guard untuk endpoint dashboard
│   ├── routes/
│   │   ├── auth.js            # Register/login user dashboard
│   │   ├── license.js         # Verifikasi lisensi EA (dipakai semua route EA)
│   │   ├── account.js         # Heartbeat EA + baca data akun
│   │   ├── settings.js        # Sinkron setting EA
│   │   ├── commands.js        # Antrian remote command
│   │   ├── version.js         # Cek versi EA
│   │   └── dashboard.js       # Agregasi data untuk tampilan dashboard
│   └── server.js
├── frontend/                  # Dashboard (HTML/CSS/JS + Chart.js)
│   ├── index.html             # Halaman login/daftar
│   ├── dashboard.html         # Halaman utama
│   ├── css/style.css
│   └── js/{config,auth,dashboard}.js
└── ea/
    ├── MT4/EA_CloudDashboard.mq4
    └── MT5/EA_CloudDashboard.mq5
```

## Setup Backend

```bash
cd backend
npm install
cp .env.example .env      # isi DB_*, REDIS_*, JWT_SECRET
```

Import skema:

```bash
mysql -u root -p < ../database/schema.sql
```

Jalankan Redis (contoh via Docker) dan API:

```bash
docker run -d --name ea-redis -p 6379:6379 redis:7
npm run dev      # atau: npm start
```

Buat user pertama & lisensi:

```bash
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Demo","email":"demo@mail.com","password":"secret123"}'
```

Lalu insert baris di tabel `licenses` (license_key bebas, mis. `ABC123`) yang
mengarah ke `user_id` hasil register — ini nanti yang dimasukkan ke input
`InpLicenseKey` di EA.

## Setup Frontend

`frontend/js/config.js` arahkan `API_BASE` ke API Anda, lalu buka
`frontend/index.html` di browser (atau host via Nginx/static hosting apa saja).

## Setup EA (MT4/MT5)

1. Copy `EA_CloudDashboard.mq4` (atau `.mq5`) ke folder `MQL4/Experts` atau
   `MQL5/Experts`, compile di MetaEditor.
2. Di terminal: **Tools → Options → Expert Advisors** → centang
   *"Allow WebRequest for listed URL"* → tambahkan domain API Anda
   (mis. `https://yourdomain.com`).
3. Pasang EA di chart, isi input:
   - `InpApiBase` = URL API Anda
   - `InpLicenseKey` = license key dari dashboard
4. EA otomatis mendaftarkan akun ke lisensi tersebut saat pertama kali jalan,
   lalu langsung muncul sebagai card baru di dashboard.

> Catatan: EA ini adalah **framework komunikasi + remote control** (heartbeat,
> sync setting, command, cek lisensi/versi). Logika entry sinyal trading ada di
> fungsi `RunStrategy()` — isi sesuai strategi Anda; semua parameter (lot, TP,
> grid, magic, max posisi, flag averaging/grid/hedging/news-filter) sudah
> otomatis tersinkron dari dashboard tanpa perlu reattach EA.

## Alur singkat

1. EA kirim heartbeat → `POST /api/account/update` → tersimpan di Redis (TTL).
2. Dashboard poll `GET /api/dashboard` tiap 3 detik → gabungkan MySQL (identitas,
   setting) + Redis (angka realtime) → render card & badge online/offline.
3. User ubah setting/klik command di dashboard → tersimpan ke MySQL, cache Redis
   settings di-invalidate.
4. EA poll `GET /api/settings` & `GET /api/commands` tiap beberapa detik →
   terapkan parameter baru / jalankan perintah → `POST /api/commands/ack`.
5. License EA dicek di setiap request EA-facing (`routes/license.js`) — kalau
   status berubah jadi suspended/expired, EA otomatis berhenti trading.

## Keamanan & catatan produksi

- Ganti `JWT_SECRET` dan semua kredensial `.env` sebelum deploy.
- Selalu pakai HTTPS untuk `InpApiBase` (WebRequest MT4/5 mendukung HTTPS).
- Tambahkan rate limiting per-license (sudah ada limiter dasar di `server.js`,
  sesuaikan angka `max` untuk jumlah akun Anda).
- `hwid` di EA dipakai untuk mengunci lisensi ke satu terminal; sesuaikan logika
  fingerprint sesuai kebutuhan (mis. tambahkan nomor akun).
