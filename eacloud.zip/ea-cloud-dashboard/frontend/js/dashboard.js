const token = localStorage.getItem('ea_token');
if (!token) window.location.href = 'index.html';

let selectedAccount = null;
let profitChart = null;
let refreshTimer = null;

document.getElementById('navLogout').addEventListener('click', (e) => {
  e.preventDefault();
  localStorage.removeItem('ea_token');
  window.location.href = 'index.html';
});
document.getElementById('closeDetail').addEventListener('click', () => {
  document.getElementById('detailPanel').classList.add('hidden');
  selectedAccount = null;
});

async function api(path, opts = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    ...opts,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
      ...(opts.headers || {}),
    },
  });
  if (res.status === 401) {
    localStorage.removeItem('ea_token');
    window.location.href = 'index.html';
    return;
  }
  return res.json();
}

function money(n) {
  const v = Number(n || 0);
  const sign = v > 0 ? '+' : '';
  return `${sign}$${v.toFixed(2)}`;
}

function statusBadge(status, online) {
  if (!online) return `<span class="badge badge-offline">● Offline</span>`;
  const map = {
    running: '<span class="badge badge-live">● Running</span>',
    paused: '<span class="badge badge-warn">● Paused</span>',
    stopped: '<span class="badge badge-off">● Stopped</span>',
  };
  return map[status] || map.stopped;
}

function renderStatRow(accounts) {
  const online = accounts.filter(a => a.online).length;
  const totalEquity = accounts.reduce((s, a) => s + Number(a.equity || 0), 0);
  const totalProfit = accounts.reduce((s, a) => s + Number(a.profit || 0), 0);

  document.getElementById('statRow').innerHTML = `
    <div class="stat-box">
      <span class="stat-label">Akun Online</span>
      <span class="stat-value">${online} / ${accounts.length}</span>
    </div>
    <div class="stat-box">
      <span class="stat-label">Total Equity</span>
      <span class="stat-value mono">$${totalEquity.toFixed(2)}</span>
    </div>
    <div class="stat-box">
      <span class="stat-label">Floating P/L</span>
      <span class="stat-value mono ${totalProfit >= 0 ? 'positive' : 'negative'}">${money(totalProfit)}</span>
    </div>
  `;
}

function renderCards(accounts) {
  const wrap = document.getElementById('accountCards');
  if (accounts.length === 0) {
    wrap.innerHTML = `<div class="empty">Belum ada akun terhubung. Pasang EA di MT4/MT5 Anda dengan License Key dari menu akun untuk mulai memonitor.</div>`;
    return;
  }

  wrap.innerHTML = accounts.map(a => `
    <article class="card" data-id="${a.id}" data-account="${a.account_number}">
      <div class="card-head">
        <span class="pulse ${a.online ? 'pulse-on' : 'pulse-off'}"></span>
        <div>
          <h3>${a.nickname || a.account_number}</h3>
          <span class="muted small">${a.broker || 'Broker —'} · ${a.platform}</span>
        </div>
        ${statusBadge(a.status, a.online)}
      </div>
      <div class="card-metrics">
        <div><span class="muted small">Balance</span><span class="mono">$${Number(a.balance || 0).toFixed(2)}</span></div>
        <div><span class="muted small">Equity</span><span class="mono">$${Number(a.equity || 0).toFixed(2)}</span></div>
        <div><span class="muted small">Floating</span><span class="mono ${Number(a.profit) >= 0 ? 'positive' : 'negative'}">${money(a.profit)}</span></div>
        <div><span class="muted small">Margin</span><span class="mono">$${Number(a.margin || 0).toFixed(2)}</span></div>
        <div><span class="muted small">Orders</span><span class="mono">${a.positions ?? '—'}</span></div>
        <div><span class="muted small">Ping</span><span class="mono">${a.ping ?? '—'} ms</span></div>
      </div>
      <button class="btn-ghost full" data-open="${a.id}">Kelola Akun →</button>
    </article>
  `).join('');

  wrap.querySelectorAll('[data-open]').forEach(btn => {
    btn.addEventListener('click', () => openDetail(accounts.find(a => a.id == btn.dataset.open)));
  });
}

async function openDetail(account) {
  selectedAccount = account;
  document.getElementById('detailPanel').classList.remove('hidden');
  document.getElementById('detailTitle').textContent = `${account.nickname || account.account_number} — ${account.platform}`;

  const form = document.getElementById('settingsForm');
  form.lots.value = account.lots ?? 0.01;
  form.grid_step.value = account.grid_step ?? 250;
  form.take_profit.value = account.take_profit ?? 500;
  form.stop_loss.value = account.stop_loss ?? '';
  form.magic_number.value = account.magic_number ?? 12345;
  form.max_positions.value = account.max_positions ?? 10;

  const stats = await api(`/dashboard/stats/${account.id}`);
  renderChart(stats.daily || []);
}

function renderChart(daily) {
  const ctx = document.getElementById('profitChart');
  const labels = daily.map(d => d.day);
  const data = daily.map(d => Number(d.profit || 0));
  if (profitChart) profitChart.destroy();
  profitChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        data,
        backgroundColor: data.map(v => v >= 0 ? '#3DDC97' : '#FF5C7A'),
        borderRadius: 4,
      }],
    },
    options: {
      plugins: { legend: { display: false } },
      scales: {
        x: { grid: { display: false }, ticks: { color: '#7C8494' } },
        y: { grid: { color: '#232838' }, ticks: { color: '#7C8494' } },
      },
    },
  });
}

document.getElementById('settingsForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!selectedAccount) return;
  const data = Object.fromEntries(new FormData(e.target).entries());
  const note = document.getElementById('saveNote');
  note.textContent = 'Menyimpan...';

  const res = await api('/settings', {
    method: 'POST',
    body: JSON.stringify({ account_id: selectedAccount.id, ...data }),
  });

  note.textContent = res && res.ok ? '✓ Tersimpan — EA akan sinkron otomatis' : 'Gagal menyimpan.';
  setTimeout(() => (note.textContent = ''), 3000);
});

document.querySelectorAll('[data-cmd]').forEach(btn => {
  btn.addEventListener('click', async () => {
    if (!selectedAccount) return;
    if (btn.dataset.cmd === 'emergency_stop' && !confirm('Yakin ingin menutup SEMUA posisi dan menghentikan trading?')) return;
    await api('/commands', {
      method: 'POST',
      body: JSON.stringify({ account_id: selectedAccount.id, command: btn.dataset.cmd }),
    });
    btn.textContent = '✓ Terkirim';
    setTimeout(() => refresh(), 800);
  });
});

async function refresh() {
  const data = await api('/dashboard');
  if (!data) return;
  renderStatRow(data.accounts);
  renderCards(data.accounts);

  if (selectedAccount) {
    const updated = data.accounts.find(a => a.id === selectedAccount.id);
    if (updated) selectedAccount = updated;
  }
}

refresh();
refreshTimer = setInterval(refresh, 3000);
